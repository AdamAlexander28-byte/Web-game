// main.js — orchestrates module rendering and interactions for the advanced .LIGHT UI

// Global application state
const state = {
  current: 'ai',
  logs: [],
  ai: {
    load: 30,
    heat: 'Cool',
    latency: 8,
    analysisRunning: false,
    dataLoaded: false,
  },
  shield: {
    power: 60,
    heat: 20,
    venting: false,
  },
  metal: {
    energy: 50,
    heat: 15,
    forging: false,
  },
  settings: {
    darkMode: false,
  },
};

// Utility: sleep returns a promise that resolves after ms milliseconds
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Logging helper: prepend log entry to log area
function pushLog(msg) {
  const timestamp = new Date().toLocaleTimeString();
  state.logs.unshift(`[${timestamp}] ${msg}`);
  const logEl = document.getElementById('log');
  if (logEl) {
    logEl.textContent = state.logs.slice(0, 50).join('\n');
  }
}

// Update status bar text
function setStatus(text) {
  const statusBar = document.getElementById('statusBar');
  if (statusBar) statusBar.textContent = text;
}

// Render the selected module
function renderModule(name) {
  state.current = name;
  const content = document.getElementById('content');
  // Remove previous children
  content.innerHTML = '';
  // Deactivate all menu items
  document.querySelectorAll('.side .item').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.mod === name);
  });
  setStatus(`Loaded ${name.charAt(0).toUpperCase() + name.slice(1)} module`);
  switch (name) {
    case 'ai':
      renderAIModule(content);
      break;
    case 'shield':
      renderShieldModule(content);
      break;
    case 'metal':
      renderMetalModule(content);
      break;
    case 'settings':
      renderSettingsModule(content);
      break;
    case 'connect':
      renderConnectModule(content);
      break;
  }
}

// Build AI Core panel
function renderAIModule(container) {
  const panel = document.createElement('div');
  panel.className = 'module-panel';
  // Graph + KPI card
  const card = document.createElement('div');
  card.className = 'card';
  card.innerHTML = `
    <h2>AI Core</h2>
    <div class="ai-graphic-wrapper">
      <!-- AI graphic: dynamic network -->
      <svg class="ai-graphic" viewBox="0 0 520 360">
        <path d="M330,288c-40,24-88,20-126,-4c-44,-27-82,-81-72,-133c12,-60,64,-94,118,-98c46,-4,86,12,114,44 c28,32,38,82,18,120c-12,24-30,42-52,54z" fill="none" stroke="#4872a6" stroke-opacity=".25" stroke-width="4" />
        <path class="flow" d="M220,170 C260,120 320,120 360,170 M240,210 C280,160 340,160 380,210 M210,200 C250,150 310,150 350,200" fill="none" stroke="#8cc9ff" stroke-width="5" stroke-linecap="round" />
        <g fill="#8cc9ff">
          <circle class="node" cx="230" cy="180" r="10" />
          <circle class="node" cx="270" cy="150" r="10" />
          <circle class="node" cx="310" cy="155" r="10" />
          <circle class="node" cx="345" cy="180" r="11" />
          <circle class="node" cx="285" cy="200" r="8" />
          <circle class="node" cx="325" cy="205" r="9" />
          <circle class="node" cx="255" cy="210" r="8" />
        </g>
      </svg>
    </div>
    <div class="kpi">
      <span class="chip">Load: <b id="kpiLoad">${state.ai.load}%</b></span>
      <span class="chip">Heat: <b id="kpiHeat">${state.ai.heat}</b></span>
      <span class="chip">Latency: <b id="kpiLatency">${state.ai.latency}ms</b></span>
    </div>
    <button id="runAnalysis" class="btn">Run Analysis</button>
    <button id="loadData" class="btn">Load Data</button>
    <div id="aiLog" style="font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 140px; overflow-y: auto; margin-top: 10px;"></div>
  `;
  panel.appendChild(card);
  container.appendChild(panel);

  // Event handlers
  document.getElementById('runAnalysis').onclick = async () => {
    if (state.ai.analysisRunning) return;
    state.ai.analysisRunning = true;
    setStatus('AI: Running analysis...');
    pushAILog('Analysis started');
    // Simulate heavy computation by calculating primes up to a random large number
    await heavyComputation();
    // Update metrics randomly
    state.ai.load = 20 + Math.floor(Math.random() * 60);
    state.ai.heat = ['Cool', 'Nominal', 'Warm'][Math.floor(Math.random() * 3)];
    state.ai.latency = 5 + Math.floor(Math.random() * 20);
    updateAIKpi();
    setStatus('AI: Analysis complete.');
    pushAILog('Analysis complete');
    state.ai.analysisRunning = false;
  };
  document.getElementById('loadData').onclick = async () => {
    if (state.ai.dataLoaded) {
      setStatus('AI: Data already loaded.');
      return;
    }
    setStatus('AI: Loading data...');
    pushAILog('Fetching data...');
    try {
      const res = await fetch('data/bigData.bin');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      let total = 0;
      const chunks = [];
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        chunks.push(value);
        total += value.length;
        setStatus(`AI: Loading data... ${(total / (1024 * 1024)).toFixed(1)} MB`);
      }
      // Combine chunks
      state.ai.dataLoaded = true;
      pushAILog(`Data loaded (${(total / (1024 * 1024)).toFixed(2)} MB)`);
      setStatus('AI: Data loaded.');
    } catch (err) {
      setStatus('AI: Failed to load data');
      pushAILog('Error: ' + err.message);
    }
  };
}

function updateAIKpi() {
  document.getElementById('kpiLoad').textContent = `${state.ai.load}%`;
  document.getElementById('kpiHeat').textContent = state.ai.heat;
  document.getElementById('kpiLatency').textContent = `${state.ai.latency}ms`;
}

function pushAILog(msg) {
  const el = document.getElementById('aiLog');
  if (el) {
    const timestamp = new Date().toLocaleTimeString();
    el.textContent = `[${timestamp}] ${msg}\n` + el.textContent;
  }
}

// Heavy computation simulation: find prime numbers until time limit
async function heavyComputation() {
  const limit = 100000; // prime numbers search limit
  const primes = [];
  for (let i = 2; i < limit; i++) {
    let isPrime = true;
    const sqrt = Math.sqrt(i);
    for (let j = 2; j <= sqrt; j++) {
      if (i % j === 0) {
        isPrime = false;
        break;
      }
    }
    if (isPrime) primes.push(i);
    // Occasionally yield to UI thread
    if (i % 5000 === 0) await sleep(0);
  }
  return primes;
}

// Shield module: simulate power/heat decay and venting
let shieldInterval;
function renderShieldModule(container) {
  const panel = document.createElement('div');
  panel.className = 'module-panel';
  panel.innerHTML = `
    <div class="card">
      <h2>Shield Core</h2>
      <div class="kpi">
        <span class="chip">Power: <b id="shieldPower">${state.shield.power}</b>%</span>
        <span class="chip">Heat: <b id="shieldHeat">${state.shield.heat}</b>%</span>
      </div>
      <div style="margin-top: 10px;">Hold anywhere to vent heat via accelerometer</div>
      <div id="shieldLog" style="font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 120px; overflow-y: auto; margin-top: 10px;"></div>
    </div>
  `;
  container.appendChild(panel);
  // Clear previous interval if exists
  if (shieldInterval) clearInterval(shieldInterval);
  // Start periodic update
  shieldInterval = setInterval(() => {
    // Natural decay
    state.shield.power = Math.max(0, state.shield.power - 0.5);
    state.shield.heat = Math.min(100, state.shield.heat + 0.3);
    // Venting effect
    if (state.shield.venting) {
      state.shield.heat = Math.max(0, state.shield.heat - 1.2);
      state.shield.power = Math.max(0, state.shield.power - 0.8);
    }
    // Update display
    document.getElementById('shieldPower').textContent = state.shield.power.toFixed(0);
    document.getElementById('shieldHeat').textContent = state.shield.heat.toFixed(0);
    if (state.shield.heat >= 100 || state.shield.power <= 0) {
      pushShieldLog('Shield critical!');
    }
  }, 300);
  // Venting via touch events
  const content = document.getElementById('content');
  const startVenting = () => { state.shield.venting = true; setStatus('Shield: Venting heat'); pushShieldLog('Venting'); };
  const stopVenting = () => { state.shield.venting = false; setStatus('Shield: Idle'); pushShieldLog('Stopped venting'); };
  content.addEventListener('pointerdown', startVenting);
  content.addEventListener('pointerup', stopVenting);
  content.addEventListener('pointerleave', stopVenting);
  // Accelerometer effect: if device moves strongly, vent more
  if (window.DeviceMotionEvent) {
    window.addEventListener('devicemotion', (ev) => {
      const acc = ev.accelerationIncludingGravity;
      const total = Math.sqrt(acc.x * acc.x + acc.y * acc.y + acc.z * acc.z);
      if (total > 20) {
        // On shake, reduce heat quickly
        state.shield.heat = Math.max(0, state.shield.heat - 4);
        pushShieldLog('Shake detected: heat vented');
      }
    });
  }
}

function pushShieldLog(msg) {
  const el = document.getElementById('shieldLog');
  if (el) {
    const timestamp = new Date().toLocaleTimeString();
    el.textContent = `[${timestamp}] ${msg}\n` + el.textContent;
  }
}

// Metal module: simulate energy conversion into score
let metalInterval;
function renderMetalModule(container) {
  const panel = document.createElement('div');
  panel.className = 'module-panel';
  panel.innerHTML = `
    <div class="card">
      <h2>Metal Core</h2>
      <div class="kpi">
        <span class="chip">Energy: <b id="metalEnergy">${state.metal.energy}</b>%</span>
        <span class="chip">Heat: <b id="metalHeat">${state.metal.heat}</b>%</span>
        <span class="chip">Progress: <b id="metalProgress">0</b>%</span>
      </div>
      <div style="margin-top: 10px;">Tap to convert energy to structure. Hold to speed up forging.</div>
      <div id="metalLog" style="font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 120px; overflow-y: auto; margin-top: 10px;"></div>
    </div>
  `;
  container.appendChild(panel);
  if (metalInterval) clearInterval(metalInterval);
  let progress = 0;
  const updateDisplay = () => {
    document.getElementById('metalEnergy').textContent = state.metal.energy.toFixed(0);
    document.getElementById('metalHeat').textContent = state.metal.heat.toFixed(0);
    document.getElementById('metalProgress').textContent = progress.toFixed(0);
  };
  updateDisplay();
  // forging loop
  metalInterval = setInterval(() => {
    // Passive cooling
    state.metal.heat = Math.max(0, state.metal.heat - 0.3);
    updateDisplay();
  }, 400);
  // Input handling
  const content = document.getElementById('content');
  let forging = false;
  content.addEventListener('pointerdown', () => {
    forging = true;
    pushMetalLog('Smelting started');
  });
  content.addEventListener('pointerup', () => {
    forging = false;
    pushMetalLog('Smelting stopped');
  });
  content.addEventListener('pointerleave', () => {
    forging = false;
  });
  // forging progress update
  setInterval(() => {
    if (forging) {
      if (state.metal.energy <= 0) {
        pushMetalLog('No energy left!');
        return;
      }
      state.metal.energy = Math.max(0, state.metal.energy - 1);
      state.metal.heat = Math.min(100, state.metal.heat + 0.5);
      progress = Math.min(100, progress + 2);
      updateDisplay();
      if (progress >= 100) {
        pushMetalLog('Forging complete! Structure upgraded.');
        progress = 0;
      }
    }
  }, 200);
}

function pushMetalLog(msg) {
  const el = document.getElementById('metalLog');
  if (el) {
    const timestamp = new Date().toLocaleTimeString();
    el.textContent = `[${timestamp}] ${msg}\n` + el.textContent;
  }
}

// Settings module: toggles
function renderSettingsModule(container) {
  const panel = document.createElement('div');
  panel.className = 'module-panel';
  panel.innerHTML = `
    <div class="card">
      <h2>Settings</h2>
      <label style="display:flex; align-items:center; gap: 8px;">
        <input type="checkbox" id="toggleDark" ${state.settings.darkMode ? 'checked' : ''} /> Dark Mode
      </label>
    </div>
  `;
  container.appendChild(panel);
  // Dark mode toggle
  const toggle = document.getElementById('toggleDark');
  toggle.onchange = (e) => {
    state.settings.darkMode = e.target.checked;
    document.body.classList.toggle('dark', state.settings.darkMode);
    if (state.settings.darkMode) {
      document.documentElement.style.setProperty('--bg1', '#1e253a');
      document.documentElement.style.setProperty('--bg2', '#0f1426');
      document.documentElement.style.setProperty('--panel', 'rgba(20, 30, 50, 0.8)');
      document.documentElement.style.setProperty('--panel-2', 'rgba(20, 30, 50, 0.6)');
      document.documentElement.style.setProperty('--text', '#eaf2ff');
      document.documentElement.style.setProperty('--muted', '#a3b3cd');
    } else {
      document.documentElement.style.setProperty('--bg1', '#eaf2ff');
      document.documentElement.style.setProperty('--bg2', '#ffffff');
      document.documentElement.style.setProperty('--panel', 'rgba(255, 255, 255, 0.8)');
      document.documentElement.style.setProperty('--panel-2', 'rgba(255, 255, 255, 0.5)');
      document.documentElement.style.setProperty('--text', '#0e1a2b');
      document.documentElement.style.setProperty('--muted', '#51607a');
    }
  };
}

// Connect module: simulate server connection
function renderConnectModule(container) {
  const panel = document.createElement('div');
  panel.className = 'module-panel';
  panel.innerHTML = `
    <div class="card">
      <h2>Connect to Server</h2>
      <div style="margin-bottom: 10px;">Simulate server connection and hardware uplink.</div>
      <input id="serverUrl" type="text" placeholder="https://example.com" style="width: 100%; padding: 8px; border: 1px solid #ccddef; border-radius: 8px;" />
      <button id="connectBtn" class="btn" style="margin-top: 10px;">Connect</button>
      <div id="connectLog" style="font-family: monospace; font-size: 12px; white-space: pre-wrap; max-height: 120px; overflow-y: auto; margin-top: 10px;"></div>
    </div>
  `;
  container.appendChild(panel);
  document.getElementById('connectBtn').onclick = async () => {
    const url = document.getElementById('serverUrl').value.trim() || 'https://example.com';
    setStatus('Connecting to server...');
    pushConnectLog('Attempting connection to ' + url);
    await sleep(800);
    // Simulate network by random success
    const success = Math.random() > 0.3;
    if (success) {
      setStatus('Connected to server.');
      pushConnectLog('Connection successful');
      document.getElementById('netDot').style.background = '#22c36c';
      document.getElementById('netStatus').textContent = 'Online';
    } else {
      setStatus('Failed to connect.');
      pushConnectLog('Connection failed');
      document.getElementById('netDot').style.background = '#b23636';
      document.getElementById('netStatus').textContent = 'Offline';
    }
  };
}

function pushConnectLog(msg) {
  const el = document.getElementById('connectLog');
  if (el) {
    const timestamp = new Date().toLocaleTimeString();
    el.textContent = `[${timestamp}] ${msg}\n` + el.textContent;
  }
}

// Initialise modules and event handlers
function init() {
  // Setup menu item clicks
  document.querySelectorAll('.side .item').forEach((btn) => {
    btn.addEventListener('click', () => {
      renderModule(btn.dataset.mod);
    });
  });
  // Render default module
  renderModule('ai');
}

// Wait for DOM ready
window.addEventListener('DOMContentLoaded', init);